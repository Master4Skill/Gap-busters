import os

speech_key = os.environ.get('SPEECH_KEY')
speech_region = os.environ.get('SPEECH_REGION')

print('Speech Key:', speech_key)
print('Speech Region:', speech_region)
